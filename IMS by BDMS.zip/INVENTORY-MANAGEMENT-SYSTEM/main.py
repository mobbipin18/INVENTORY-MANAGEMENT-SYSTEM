from tkinter import *

q=Tk()
q.title('Main window')
q.geometry('427x250')
l1=Label(q,text='ADD TEXT HERE ',fg='grey',bg=None)
l=('Calibri (Body)',24,'bold')
l1.config(font=l)
l1.pack(expand=True)
    
    
    
q.mainloop()
